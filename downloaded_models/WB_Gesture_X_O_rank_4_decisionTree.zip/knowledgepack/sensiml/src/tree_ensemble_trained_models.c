/*
Copyright 2017-2024 SensiML Corporation

This file is part of SensiML™ Piccolo AI™.

SensiML Piccolo AI is free software: you can redistribute it and/or
modify it under the terms of the GNU Affero General Public License
as published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

SensiML Piccolo AI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public
License along with SensiML Piccolo AI. If not, see <https://www.gnu.org/licenses/>.
*/

#include "tree_ensemble_trained_models.h"

uint16_t model_0_left_children_tree_0[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 12, 0, 0, 15, 0, 17, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_0[23] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 13, 0, 0, 16, 0, 20, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_0[23] = {37, 173, 34, 245, 0, 0, 239, 0, 0, 188, 0, 19, 0, 0, 165, 0, 226, 208, 0, 0, 125, 0, 0};
uint16_t model_0_features_tree_0[23] = {2, 1, 2, 0, 0, 0, 0, 1, 0, 1, 1, 2, 1, 2, 0, 1, 0, 1, 1, 2, 1, 0, 2};
uint16_t model_0_left_children_tree_1[21] = {1, 2, 3, 0, 5, 0, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 17, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_1[21] = {8, 7, 4, 0, 6, 0, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 18, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_1[21] = {29, 173, 240, 0, 241, 0, 0, 0, 85, 228, 167, 0, 0, 98, 0, 0, 104, 0, 226, 0, 0};
uint16_t model_0_features_tree_1[21] = {2, 1, 0, 0, 0, 1, 0, 1, 2, 0, 0, 1, 2, 1, 0, 1, 1, 2, 1, 1, 1};
uint16_t model_0_left_children_tree_2[23] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 0, 17, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_2[23] = {14, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 13, 0, 0, 16, 0, 20, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_2[23] = {169, 29, 240, 0, 241, 0, 0, 90, 67, 0, 0, 98, 0, 0, 164, 0, 199, 22, 0, 0, 204, 0, 0};
uint16_t model_0_features_tree_2[23] = {1, 2, 0, 0, 0, 0, 0, 1, 1, 2, 2, 1, 0, 1, 0, 1, 0, 2, 1, 2, 0, 1, 1};
uint16_t model_0_left_children_tree_3[25] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 0, 13, 14, 0, 16, 0, 0, 19, 20, 0, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_3[25] = {12, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 0, 18, 15, 0, 17, 0, 0, 22, 21, 0, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_3[25] = {221, 85, 21, 0, 79, 0, 0, 98, 121, 0, 0, 0, 233, 26, 0, 230, 0, 0, 36, 9, 0, 0, 42, 0, 0};
uint16_t model_0_features_tree_3[25] = {0, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 0, 2, 0, 0, 2, 1, 2, 2, 0, 0, 2, 2, 0};
uint16_t model_0_left_children_tree_4[17] = {1, 2, 0, 4, 5, 0, 0, 8, 0, 0, 11, 12, 13, 0, 0, 0, 0};
uint16_t model_0_right_children_tree_4[17] = {10, 3, 0, 7, 6, 0, 0, 9, 0, 0, 16, 15, 14, 0, 0, 0, 0};
uint8_t model_0_threshold_tree_4[17] = {221, 168, 0, 207, 103, 0, 0, 222, 0, 0, 127, 123, 247, 0, 0, 0, 0};
uint16_t model_0_features_tree_4[17] = {0, 0, 1, 1, 1, 2, 1, 1, 2, 2, 1, 1, 0, 0, 0, 1, 0};
uint16_t model_0_left_children_tree_5[25] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 0, 15, 16, 17, 0, 0, 0, 21, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_5[25] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 0, 20, 19, 18, 0, 0, 0, 22, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_5[25] = {221, 215, 191, 167, 0, 0, 27, 0, 0, 103, 222, 0, 0, 0, 233, 49, 231, 0, 0, 0, 245, 0, 1, 0, 0};
uint16_t model_0_features_tree_5[25] = {0, 1, 0, 0, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0, 2, 0, 0, 1, 2, 0, 0, 2, 1, 0};
uint16_t model_0_left_children_tree_6[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 12, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_6[23] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 13, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_6[23] = {233, 85, 210, 92, 0, 0, 153, 0, 0, 117, 0, 193, 0, 0, 127, 124, 105, 0, 0, 10, 0, 0, 0};
uint16_t model_0_features_tree_6[23] = {0, 2, 1, 1, 2, 1, 0, 1, 2, 1, 2, 0, 1, 1, 1, 1, 1, 0, 0, 2, 0, 0, 0};
uint16_t model_0_left_children_tree_7[19] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 0, 13, 14, 0, 16, 0, 0, 0};
uint16_t model_0_right_children_tree_7[19] = {12, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 0, 18, 15, 0, 17, 0, 0, 0};
uint8_t model_0_threshold_tree_7[19] = {171, 52, 34, 221, 0, 0, 108, 0, 0, 181, 0, 0, 85, 188, 0, 165, 0, 0, 0};
uint16_t model_0_features_tree_7[19] = {1, 2, 2, 0, 0, 0, 1, 0, 1, 0, 1, 2, 2, 1, 1, 0, 1, 2, 1};
uint16_t model_0_left_children_tree_8[23] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 0, 13, 14, 0, 16, 0, 0, 19, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_8[23] = {12, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 0, 18, 15, 0, 17, 0, 0, 20, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_8[23] = {219, 173, 211, 0, 240, 0, 0, 205, 99, 0, 0, 0, 233, 29, 0, 230, 0, 0, 245, 0, 246, 0, 0};
uint16_t model_0_features_tree_8[23] = {0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 0, 2, 0, 0, 2, 1, 0, 0, 0, 1, 0};
uint16_t model_0_left_children_tree_9[23] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 0, 17, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_9[23] = {14, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 13, 0, 0, 16, 0, 20, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_9[23] = {170, 36, 240, 0, 124, 0, 0, 52, 243, 0, 0, 74, 0, 0, 165, 0, 197, 187, 0, 0, 30, 0, 0};
uint16_t model_0_features_tree_9[23] = {1, 2, 0, 0, 1, 0, 0, 2, 0, 2, 0, 2, 2, 2, 0, 1, 0, 0, 2, 2, 2, 2, 1};
uint16_t model_0_left_children_tree_10[25] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 14, 0, 0, 17, 18, 19, 0, 0, 22, 0, 0, 0};
uint16_t model_0_right_children_tree_10[25] = {16, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 15, 0, 0, 24, 21, 20, 0, 0, 23, 0, 0, 0};
uint8_t model_0_threshold_tree_10[25] = {164, 222, 203, 199, 0, 0, 91, 0, 0, 245, 54, 0, 0, 1, 0, 0, 84, 47, 31, 0, 0, 198, 0, 0, 0};
uint16_t model_0_features_tree_10[25] = {1, 0, 0, 0, 2, 1, 1, 2, 2, 0, 2, 0, 2, 2, 1, 0, 2, 2, 2, 2, 1, 1, 1, 2, 1};
uint16_t model_0_left_children_tree_11[27] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 23, 24, 0, 0, 0};
uint16_t model_0_right_children_tree_11[27] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 26, 25, 0, 0, 0};
uint8_t model_0_threshold_tree_11[27] = {219, 210, 183, 84, 0, 0, 40, 0, 0, 105, 214, 0, 0, 0, 246, 222, 29, 0, 0, 54, 0, 0, 247, 41, 0, 0, 0};
uint16_t model_0_features_tree_11[27] = {0, 1, 0, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 0, 0, 2, 0, 1, 2, 0, 2, 0, 2, 2, 0, 0};
uint16_t model_0_left_children_tree_12[25] = {1, 2, 3, 0, 5, 0, 0, 8, 0, 10, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 22, 0, 0, 0};
uint16_t model_0_right_children_tree_12[25] = {12, 7, 4, 0, 6, 0, 0, 9, 0, 11, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 24, 23, 0, 0, 0};
uint8_t model_0_threshold_tree_12[25] = {36, 174, 1, 0, 29, 0, 0, 28, 0, 31, 0, 0, 215, 118, 40, 0, 0, 207, 0, 0, 249, 107, 0, 0, 0};
uint16_t model_0_features_tree_12[25] = {2, 1, 2, 1, 2, 0, 0, 2, 1, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1};
uint16_t model_0_left_children_tree_13[19] = {1, 2, 3, 4, 0, 0, 0, 8, 0, 0, 11, 12, 0, 14, 0, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_13[19] = {10, 7, 6, 5, 0, 0, 0, 9, 0, 0, 16, 13, 0, 15, 0, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_13[19] = {221, 85, 213, 203, 0, 0, 0, 104, 0, 0, 233, 226, 0, 44, 0, 0, 1, 0, 0};
uint16_t model_0_features_tree_13[19] = {0, 2, 1, 0, 1, 2, 2, 1, 2, 1, 0, 0, 0, 2, 0, 2, 2, 1, 0};
uint16_t model_0_left_children_tree_14[21] = {1, 2, 3, 4, 0, 0, 0, 8, 9, 0, 0, 0, 13, 0, 15, 16, 0, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_14[21] = {12, 7, 6, 5, 0, 0, 0, 11, 10, 0, 0, 0, 14, 0, 18, 17, 0, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_14[21] = {164, 36, 127, 242, 0, 0, 0, 232, 224, 0, 0, 0, 165, 0, 199, 175, 0, 0, 189, 0, 0};
uint16_t model_0_features_tree_14[21] = {1, 2, 1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 2, 2, 1, 1, 2};
uint16_t model_0_left_children_tree_15[21] = {1, 2, 3, 0, 0, 6, 7, 0, 0, 10, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_15[21] = {12, 5, 4, 0, 0, 9, 8, 0, 0, 11, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_15[21] = {170, 76, 250, 0, 0, 29, 127, 0, 0, 54, 0, 0, 89, 199, 48, 0, 0, 189, 0, 0, 0};
uint16_t model_0_features_tree_15[21] = {1, 1, 0, 2, 0, 2, 1, 0, 0, 2, 0, 2, 2, 0, 2, 1, 2, 1, 1, 2, 1};
uint16_t model_0_left_children_tree_16[25] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 16, 0, 18, 0, 0, 21, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_16[25] = {14, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 13, 0, 0, 20, 17, 0, 19, 0, 0, 22, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_16[25] = {172, 36, 1, 0, 29, 0, 0, 234, 203, 0, 0, 42, 0, 0, 215, 173, 0, 37, 0, 0, 128, 0, 224, 0, 0};
uint16_t model_0_features_tree_16[25] = {1, 2, 2, 1, 2, 0, 0, 0, 0, 2, 2, 2, 2, 0, 1, 0, 1, 2, 1, 1, 0, 1, 1, 2, 2};
uint16_t model_0_left_children_tree_17[21] = {1, 2, 3, 4, 0, 0, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 17, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_17[21] = {8, 7, 6, 5, 0, 0, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 18, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_17[21] = {25, 183, 127, 242, 0, 0, 0, 0, 234, 87, 36, 0, 0, 223, 0, 0, 38, 0, 243, 0, 0};
uint16_t model_0_features_tree_17[21] = {2, 1, 1, 0, 0, 0, 0, 1, 0, 2, 2, 1, 2, 1, 1, 1, 2, 0, 0, 0, 0};
uint16_t model_0_left_children_tree_18[23] = {1, 2, 3, 4, 0, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 0, 17, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_18[23] = {14, 7, 6, 5, 0, 0, 0, 11, 10, 0, 0, 13, 0, 0, 16, 0, 20, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_18[23] = {37, 25, 181, 127, 0, 0, 0, 32, 200, 0, 0, 230, 0, 0, 165, 0, 210, 191, 0, 0, 63, 0, 0};
uint16_t model_0_features_tree_18[23] = {2, 2, 1, 1, 0, 0, 1, 2, 0, 2, 1, 0, 1, 0, 0, 1, 1, 0, 1, 2, 2, 2, 2};
uint16_t model_0_left_children_tree_19[23] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_19[23] = {14, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 13, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_19[23] = {165, 75, 50, 0, 31, 0, 0, 36, 127, 0, 0, 105, 0, 0, 85, 47, 217, 0, 0, 189, 0, 0, 0};
uint16_t model_0_features_tree_19[23] = {1, 1, 1, 2, 2, 0, 2, 2, 1, 0, 0, 1, 0, 1, 2, 2, 0, 1, 0, 1, 1, 2, 1};
tree_t forest_ensemble_models_0[20] = {
	{
		.left_children = model_0_left_children_tree_0,
		.right_children = model_0_right_children_tree_0,
		.threshold = model_0_threshold_tree_0,
		.features = model_0_features_tree_0,
	},
	{
		.left_children = model_0_left_children_tree_1,
		.right_children = model_0_right_children_tree_1,
		.threshold = model_0_threshold_tree_1,
		.features = model_0_features_tree_1,
	},
	{
		.left_children = model_0_left_children_tree_2,
		.right_children = model_0_right_children_tree_2,
		.threshold = model_0_threshold_tree_2,
		.features = model_0_features_tree_2,
	},
	{
		.left_children = model_0_left_children_tree_3,
		.right_children = model_0_right_children_tree_3,
		.threshold = model_0_threshold_tree_3,
		.features = model_0_features_tree_3,
	},
	{
		.left_children = model_0_left_children_tree_4,
		.right_children = model_0_right_children_tree_4,
		.threshold = model_0_threshold_tree_4,
		.features = model_0_features_tree_4,
	},
	{
		.left_children = model_0_left_children_tree_5,
		.right_children = model_0_right_children_tree_5,
		.threshold = model_0_threshold_tree_5,
		.features = model_0_features_tree_5,
	},
	{
		.left_children = model_0_left_children_tree_6,
		.right_children = model_0_right_children_tree_6,
		.threshold = model_0_threshold_tree_6,
		.features = model_0_features_tree_6,
	},
	{
		.left_children = model_0_left_children_tree_7,
		.right_children = model_0_right_children_tree_7,
		.threshold = model_0_threshold_tree_7,
		.features = model_0_features_tree_7,
	},
	{
		.left_children = model_0_left_children_tree_8,
		.right_children = model_0_right_children_tree_8,
		.threshold = model_0_threshold_tree_8,
		.features = model_0_features_tree_8,
	},
	{
		.left_children = model_0_left_children_tree_9,
		.right_children = model_0_right_children_tree_9,
		.threshold = model_0_threshold_tree_9,
		.features = model_0_features_tree_9,
	},
	{
		.left_children = model_0_left_children_tree_10,
		.right_children = model_0_right_children_tree_10,
		.threshold = model_0_threshold_tree_10,
		.features = model_0_features_tree_10,
	},
	{
		.left_children = model_0_left_children_tree_11,
		.right_children = model_0_right_children_tree_11,
		.threshold = model_0_threshold_tree_11,
		.features = model_0_features_tree_11,
	},
	{
		.left_children = model_0_left_children_tree_12,
		.right_children = model_0_right_children_tree_12,
		.threshold = model_0_threshold_tree_12,
		.features = model_0_features_tree_12,
	},
	{
		.left_children = model_0_left_children_tree_13,
		.right_children = model_0_right_children_tree_13,
		.threshold = model_0_threshold_tree_13,
		.features = model_0_features_tree_13,
	},
	{
		.left_children = model_0_left_children_tree_14,
		.right_children = model_0_right_children_tree_14,
		.threshold = model_0_threshold_tree_14,
		.features = model_0_features_tree_14,
	},
	{
		.left_children = model_0_left_children_tree_15,
		.right_children = model_0_right_children_tree_15,
		.threshold = model_0_threshold_tree_15,
		.features = model_0_features_tree_15,
	},
	{
		.left_children = model_0_left_children_tree_16,
		.right_children = model_0_right_children_tree_16,
		.threshold = model_0_threshold_tree_16,
		.features = model_0_features_tree_16,
	},
	{
		.left_children = model_0_left_children_tree_17,
		.right_children = model_0_right_children_tree_17,
		.threshold = model_0_threshold_tree_17,
		.features = model_0_features_tree_17,
	},
	{
		.left_children = model_0_left_children_tree_18,
		.right_children = model_0_right_children_tree_18,
		.threshold = model_0_threshold_tree_18,
		.features = model_0_features_tree_18,
	},
	{
		.left_children = model_0_left_children_tree_19,
		.right_children = model_0_right_children_tree_19,
		.threshold = model_0_threshold_tree_19,
		.features = model_0_features_tree_19,
	},
};
tree_ensemble_classifier_rows_t tree_ensemble_classifier_rows[1] = {

	{
		.number_of_classes=3,
		.number_of_trees=20,
		.tree_ensemble=forest_ensemble_models_0,
	},
};

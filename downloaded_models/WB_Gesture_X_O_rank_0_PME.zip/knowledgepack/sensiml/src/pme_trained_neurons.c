/*
Copyright 2017-2024 SensiML Corporation

This file is part of SensiML™ Piccolo AI™.

SensiML Piccolo AI is free software: you can redistribute it and/or
modify it under the terms of the GNU Affero General Public License
as published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

SensiML Piccolo AI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public
License along with SensiML Piccolo AI. If not, see <https://www.gnu.org/licenses/>.
*/

#include "pme_trained_neurons.h"

static qm_pme_neuron_vector_t kb_neuron_vectors_0[MAX_NUM_NEURONS_0] = 
{
	{.vector={240, 129, 13, 91, 29, 14, 70, 48, 83, 29}},
	{.vector={196, 194, 31, 243, 122, 31, 57, 164, 163, 93}},
	{.vector={193, 194, 32, 191, 73, 10, 65, 59, 147, 17}},
	{.vector={200, 189, 85, 189, 100, 58, 80, 185, 139, 63}},
	{.vector={224, 168, 9, 131, 118, 10, 54, 95, 106, 24}},
	{.vector={202, 134, 33, 76, 98, 44, 16, 89, 87, 40}},
	{.vector={219, 27, 49, 100, 255, 37, 25, 100, 10, 46}},
	{.vector={183, 203, 38, 197, 65, 42, 30, 171, 163, 105}},
	{.vector={177, 211, 57, 212, 124, 64, 39, 194, 158, 124}},
	{.vector={48, 206, 144, 205, 110, 102, 40, 191, 179, 64}},
	{.vector={198, 216, 40, 209, 57, 48, 35, 173, 149, 100}},
	{.vector={120, 181, 93, 145, 96, 83, 14, 157, 143, 139}},
	{.vector={246, 102, 11, 44, 45, 0, 51, 38, 64, 32}},
	{.vector={229, 149, 42, 87, 122, 56, 33, 139, 53, 79}},
	{.vector={220, 166, 49, 134, 86, 33, 32, 110, 123, 81}},
	{.vector={179, 223, 74, 219, 65, 58, 41, 150, 185, 56}},
	{.vector={247, 77, 25, 5, 61, 37, 48, 25, 42, 6}},
	{.vector={248, 102, 46, 37, 130, 25, 41, 37, 55, 19}},
	{.vector={250, 107, 55, 60, 23, 6, 94, 68, 66, 41}},
	{.vector={249, 109, 30, 50, 29, 14, 65, 51, 58, 27}},
	{.vector={251, 103, 9, 44, 79, 12, 57, 39, 62, 13}},
	{.vector={208, 90, 59, 48, 170, 80, 4, 90, 33, 42}},
	{.vector={204, 190, 29, 196, 102, 29, 41, 113, 151, 58}},
	{.vector={211, 162, 33, 122, 108, 42, 45, 126, 108, 79}},
	{.vector={229, 94, 27, 28, 98, 42, 28, 53, 45, 10}},
	{.vector={179, 247, 59, 214, 69, 64, 18, 187, 165, 102}},
	{.vector={193, 208, 42, 207, 67, 44, 36, 146, 164, 60}},
	{.vector={205, 185, 48, 192, 43, 32, 61, 149, 152, 91}},
	{.vector={242, 108, 37, 69, 148, 39, 16, 127, 63, 23}},
	{.vector={139, 209, 93, 198, 79, 59, 24, 202, 147, 133}},
	{.vector={247, 64, 32, 42, 98, 37, 36, 121, 39, 31}},
	{.vector={236, 97, 18, 24, 17, 13, 41, 51, 45, 6}},
};
qm_pme_neuron_attribute_t kb_neuron_attribs_0[MAX_NUM_NEURONS_0] = 
{
	{ .influence=122, .category=1 },
	{ .influence=189, .category=3 },
	{ .influence=194, .category=2 },
	{ .influence=227, .category=2 },
	{ .influence=191, .category=1 },
	{ .influence=211, .category=2 },
	{ .influence=250, .category=3 },
	{ .influence=82, .category=2 },
	{ .influence=154, .category=3 },
	{ .influence=250, .category=2 },
	{ .influence=114, .category=3 },
	{ .influence=206, .category=2 },
	{ .influence=82, .category=2 },
	{ .influence=183, .category=3 },
	{ .influence=118, .category=2 },
	{ .influence=123, .category=2 },
	{ .influence=140, .category=1 },
	{ .influence=143, .category=1 },
	{ .influence=120, .category=1 },
	{ .influence=125, .category=1 },
	{ .influence=122, .category=1 },
	{ .influence=250, .category=3 },
	{ .influence=156, .category=3 },
	{ .influence=250, .category=3 },
	{ .influence=152, .category=1 },
	{ .influence=201, .category=3 },
	{ .influence=163, .category=3 },
	{ .influence=250, .category=2 },
	{ .influence=191, .category=3 },
	{ .influence=250, .category=2 },
	{ .influence=250, .category=3 },
	{ .influence=250, .category=1 },
};
kb_classifier_row_t kb_classifier_rows[1] = {
	

	{
		.classifier_id=0,
		.num_patterns=NUM_NEURONS_0,
		.pattern_size=10,
		.max_patterns=MAX_NUM_NEURONS_0,
		.num_classes=NUM_CLASSES_0,
		.num_channels=1,
		.classifier_mode=KB_CLASSIFICATION_KNN,
		.norm_mode=KB_DISTANCE_L1,
		.stored_patterns=kb_neuron_vectors_0,
		.stored_attribs=kb_neuron_attribs_0,
	},
};

const int32_t neurons_count = KB_TOTAL_NUMBER_OF_NEURONS;

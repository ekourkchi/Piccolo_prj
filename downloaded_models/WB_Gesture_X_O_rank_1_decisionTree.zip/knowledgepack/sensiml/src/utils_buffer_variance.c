/*
Copyright 2017-2024 SensiML Corporation

This file is part of SensiML™ Piccolo AI™.

SensiML Piccolo AI is free software: you can redistribute it and/or
modify it under the terms of the GNU Affero General Public License
as published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

SensiML Piccolo AI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public
License along with SensiML Piccolo AI. If not, see <https://www.gnu.org/licenses/>.
*/




#include "kbutils.h"

FLOAT buffer_variance(ringb *pringb, int32_t base_index, int32_t offset, int32_t nrows)
{
    int32_t i;
    FLOAT sum = 0.0;
    int32_t start_index = base_index + offset;

    // Compute the mean of the input data
    FLOAT xmean = buffer_mean(pringb, base_index, offset, nrows);

    for (i = 0; i < nrows; i++)
    {
        FLOAT tmp = (FLOAT)MOD_READ_RINGBUF(pringb, start_index++) - xmean;
        sum += tmp * tmp;
    }

    return (FLOAT)(sum / nrows);
}

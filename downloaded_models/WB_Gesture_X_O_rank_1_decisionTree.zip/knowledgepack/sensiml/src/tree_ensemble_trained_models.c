/*
Copyright 2017-2024 SensiML Corporation

This file is part of SensiML™ Piccolo AI™.

SensiML Piccolo AI is free software: you can redistribute it and/or
modify it under the terms of the GNU Affero General Public License
as published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

SensiML Piccolo AI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public
License along with SensiML Piccolo AI. If not, see <https://www.gnu.org/licenses/>.
*/

#include "tree_ensemble_trained_models.h"

uint16_t model_0_left_children_tree_0[19] = {1, 2, 0, 4, 5, 0, 0, 0, 9, 10, 0, 0, 13, 14, 0, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_0[19] = {8, 3, 0, 7, 6, 0, 0, 0, 12, 11, 0, 0, 16, 15, 0, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_0[19] = {222, 167, 0, 70, 92, 0, 0, 0, 2, 23, 0, 0, 26, 25, 0, 0, 82, 0, 0};
uint16_t model_0_features_tree_0[19] = {0, 0, 1, 8, 3, 2, 2, 1, 14, 6, 0, 1, 6, 13, 0, 0, 4, 0, 2};
uint16_t model_0_left_children_tree_1[17] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 13, 0, 0, 0, 0};
uint16_t model_0_right_children_tree_1[17] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 16, 15, 14, 0, 0, 0, 0};
uint8_t model_0_threshold_tree_1[17] = {219, 72, 95, 60, 0, 0, 65, 0, 0, 0, 252, 108, 1, 0, 0, 0, 0};
uint16_t model_0_features_tree_1[17] = {0, 1, 12, 6, 1, 2, 7, 1, 2, 1, 11, 12, 5, 1, 0, 2, 1};
uint16_t model_0_left_children_tree_2[23] = {1, 2, 3, 4, 0, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_2[23] = {12, 7, 6, 5, 0, 0, 0, 11, 10, 0, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_2[23] = {221, 97, 61, 39, 0, 0, 0, 100, 83, 0, 0, 0, 44, 52, 125, 0, 0, 25, 0, 0, 119, 0, 0};
uint16_t model_0_features_tree_2[23] = {0, 3, 1, 1, 1, 2, 1, 5, 8, 2, 1, 1, 15, 4, 7, 0, 0, 1, 1, 2, 7, 2, 1};
uint16_t model_0_left_children_tree_3[15] = {1, 2, 0, 4, 0, 6, 0, 0, 9, 0, 11, 12, 0, 0, 0};
uint16_t model_0_right_children_tree_3[15] = {8, 3, 0, 5, 0, 7, 0, 0, 10, 0, 14, 13, 0, 0, 0};
uint8_t model_0_threshold_tree_3[15] = {87, 216, 0, 60, 0, 1, 0, 0, 162, 0, 73, 35, 0, 0, 0};
uint16_t model_0_features_tree_3[15] = {12, 0, 1, 7, 1, 5, 1, 0, 0, 1, 8, 5, 1, 2, 1};
uint16_t model_0_left_children_tree_4[19] = {1, 2, 3, 0, 5, 0, 0, 8, 0, 0, 11, 12, 13, 0, 0, 16, 0, 0, 0};
uint16_t model_0_right_children_tree_4[19] = {10, 7, 4, 0, 6, 0, 0, 9, 0, 0, 18, 15, 14, 0, 0, 17, 0, 0, 0};
uint8_t model_0_threshold_tree_4[19] = {21, 144, 214, 0, 216, 0, 0, 37, 0, 0, 70, 202, 74, 0, 0, 65, 0, 0, 0};
uint16_t model_0_features_tree_4[19] = {14, 3, 0, 1, 9, 1, 0, 4, 0, 2, 8, 2, 13, 2, 1, 1, 2, 1, 1};
uint16_t model_0_left_children_tree_5[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 12, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_5[23] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 13, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_5[23] = {52, 148, 60, 24, 0, 0, 106, 0, 0, 161, 0, 82, 0, 0, 71, 47, 115, 0, 0, 138, 0, 0, 0};
uint16_t model_0_features_tree_5[23] = {4, 2, 15, 14, 0, 0, 2, 1, 2, 10, 1, 3, 1, 2, 8, 5, 12, 1, 2, 15, 2, 1, 1};
uint16_t model_0_left_children_tree_6[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_6[23] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_6[23] = {42, 53, 217, 54, 0, 0, 125, 0, 0, 72, 183, 0, 0, 0, 66, 50, 129, 0, 0, 40, 0, 0, 0};
uint16_t model_0_features_tree_6[23] = {15, 5, 9, 13, 2, 1, 7, 0, 0, 1, 2, 2, 1, 1, 1, 3, 2, 0, 1, 8, 2, 2, 1};
uint16_t model_0_left_children_tree_7[25] = {1, 2, 3, 0, 5, 0, 0, 8, 0, 10, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_7[25] = {12, 7, 4, 0, 6, 0, 0, 9, 0, 11, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 22, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_7[25] = {43, 47, 216, 0, 12, 0, 0, 5, 0, 103, 0, 0, 203, 53, 128, 0, 0, 177, 0, 0, 166, 0, 146, 0, 0};
uint16_t model_0_features_tree_7[25] = {8, 4, 9, 1, 1, 0, 0, 14, 1, 3, 1, 2, 2, 13, 7, 2, 0, 3, 1, 2, 0, 1, 10, 1, 2};
uint16_t model_0_left_children_tree_8[21] = {1, 2, 0, 4, 5, 0, 0, 0, 9, 10, 0, 12, 0, 0, 15, 16, 0, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_8[21] = {8, 3, 0, 7, 6, 0, 0, 0, 14, 11, 0, 13, 0, 0, 18, 17, 0, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_8[21] = {212, 66, 0, 70, 50, 0, 0, 0, 36, 64, 0, 1, 0, 0, 96, 37, 0, 0, 203, 0, 0};
uint16_t model_0_features_tree_8[21] = {10, 7, 1, 8, 4, 1, 2, 1, 5, 7, 1, 5, 1, 0, 3, 8, 0, 2, 0, 2, 2};
uint16_t model_0_left_children_tree_9[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 14, 0, 0, 17, 0, 19, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_9[23] = {16, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 15, 0, 0, 18, 0, 20, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_9[23] = {221, 99, 160, 232, 0, 0, 63, 0, 0, 66, 56, 0, 0, 77, 0, 0, 60, 0, 216, 0, 46, 0, 0};
uint16_t model_0_features_tree_9[23] = {0, 3, 12, 9, 1, 2, 1, 2, 1, 8, 4, 2, 2, 1, 2, 1, 7, 1, 9, 1, 14, 0, 2};
uint16_t model_0_left_children_tree_10[23] = {1, 2, 3, 4, 0, 0, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 17, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_10[23] = {8, 7, 6, 5, 0, 0, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 20, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_10[23] = {27, 84, 34, 19, 0, 0, 0, 0, 61, 26, 36, 0, 0, 36, 0, 0, 24, 11, 0, 0, 221, 0, 0};
uint16_t model_0_features_tree_10[23] = {5, 13, 13, 14, 0, 1, 0, 1, 1, 15, 2, 0, 1, 5, 1, 2, 14, 14, 1, 2, 12, 1, 1};
uint16_t model_0_left_children_tree_11[23] = {1, 2, 3, 0, 5, 0, 0, 8, 0, 0, 11, 12, 13, 0, 0, 16, 0, 0, 19, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_11[23] = {10, 7, 4, 0, 6, 0, 0, 9, 0, 0, 18, 15, 14, 0, 0, 17, 0, 0, 22, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_11[23] = {37, 155, 68, 0, 53, 0, 0, 74, 0, 0, 67, 69, 55, 0, 0, 139, 0, 0, 72, 113, 0, 0, 0};
uint16_t model_0_features_tree_11[23] = {5, 2, 7, 1, 4, 0, 2, 13, 2, 1, 1, 12, 5, 0, 1, 7, 2, 1, 1, 12, 1, 2, 1};
uint16_t model_0_left_children_tree_12[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_12[23] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_12[23] = {223, 203, 212, 219, 0, 0, 77, 0, 0, 102, 75, 0, 0, 0, 252, 9, 103, 0, 0, 24, 0, 0, 0};
uint16_t model_0_features_tree_12[23] = {0, 2, 10, 0, 1, 1, 1, 2, 1, 13, 1, 2, 1, 1, 11, 14, 12, 0, 2, 14, 0, 0, 1};
uint16_t model_0_left_children_tree_13[21] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 16, 0, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_13[21] = {14, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 13, 0, 0, 20, 17, 0, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_13[21] = {131, 59, 219, 0, 249, 0, 0, 65, 52, 0, 0, 67, 0, 0, 48, 36, 0, 124, 0, 0, 0};
uint16_t model_0_features_tree_13[21] = {7, 12, 0, 1, 9, 0, 0, 1, 3, 1, 2, 1, 1, 1, 8, 14, 0, 12, 1, 2, 1};
uint16_t model_0_left_children_tree_14[17] = {1, 2, 3, 0, 5, 0, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 0};
uint16_t model_0_right_children_tree_14[17] = {8, 7, 4, 0, 6, 0, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 0};
uint8_t model_0_threshold_tree_14[17] = {29, 156, 24, 0, 38, 0, 0, 0, 96, 101, 70, 0, 0, 20, 0, 0, 0};
uint16_t model_0_features_tree_14[17] = {5, 2, 14, 0, 13, 1, 0, 1, 13, 3, 8, 2, 1, 15, 0, 2, 1};
uint16_t model_0_left_children_tree_15[19] = {1, 2, 0, 4, 5, 0, 0, 8, 0, 0, 11, 12, 0, 0, 15, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_15[19] = {10, 3, 0, 7, 6, 0, 0, 9, 0, 0, 14, 13, 0, 0, 16, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_15[19] = {87, 213, 0, 61, 233, 0, 0, 16, 0, 0, 65, 226, 0, 0, 154, 0, 199, 0, 0};
uint16_t model_0_features_tree_15[19] = {12, 9, 1, 7, 11, 2, 1, 6, 0, 0, 7, 10, 1, 2, 10, 1, 2, 2, 2};
uint16_t model_0_left_children_tree_16[17] = {1, 2, 3, 4, 0, 0, 0, 8, 0, 0, 11, 12, 13, 0, 0, 0, 0};
uint16_t model_0_right_children_tree_16[17] = {10, 7, 6, 5, 0, 0, 0, 9, 0, 0, 16, 15, 14, 0, 0, 0, 0};
uint8_t model_0_threshold_tree_16[17] = {223, 191, 159, 188, 0, 0, 0, 107, 0, 0, 251, 108, 56, 0, 0, 0, 0};
uint16_t model_0_features_tree_16[17] = {0, 12, 3, 2, 1, 1, 2, 5, 2, 1, 11, 12, 4, 0, 1, 2, 1};
uint16_t model_0_left_children_tree_17[23] = {1, 2, 3, 4, 0, 0, 0, 8, 0, 10, 0, 0, 13, 14, 0, 16, 0, 0, 19, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_17[23] = {12, 7, 6, 5, 0, 0, 0, 9, 0, 11, 0, 0, 18, 15, 0, 17, 0, 0, 22, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_17[23] = {219, 103, 67, 99, 0, 0, 0, 234, 0, 92, 0, 0, 44, 24, 0, 53, 0, 0, 115, 252, 0, 0, 0};
uint16_t model_0_features_tree_17[23] = {0, 6, 1, 3, 1, 2, 1, 2, 1, 11, 1, 2, 4, 14, 0, 2, 1, 0, 12, 10, 1, 0, 2};
uint16_t model_0_left_children_tree_18[15] = {1, 2, 3, 0, 0, 0, 7, 8, 9, 0, 0, 12, 0, 0, 0};
uint16_t model_0_right_children_tree_18[15] = {6, 5, 4, 0, 0, 0, 14, 11, 10, 0, 0, 13, 0, 0, 0};
uint8_t model_0_threshold_tree_18[15] = {32, 31, 50, 0, 0, 0, 96, 20, 234, 0, 0, 71, 0, 0, 0};
uint16_t model_0_features_tree_18[15] = {5, 14, 15, 0, 2, 1, 13, 15, 0, 1, 0, 8, 2, 1, 1};
uint16_t model_0_left_children_tree_19[17] = {1, 2, 3, 4, 0, 0, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 0};
uint16_t model_0_right_children_tree_19[17] = {8, 7, 6, 5, 0, 0, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 0};
uint8_t model_0_threshold_tree_19[17] = {218, 68, 147, 68, 0, 0, 0, 0, 103, 69, 28, 0, 0, 1, 0, 0, 0};
uint16_t model_0_features_tree_19[17] = {9, 8, 7, 1, 2, 1, 1, 1, 12, 7, 1, 0, 1, 5, 1, 0, 2};
uint16_t model_0_left_children_tree_20[17] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 0, 15, 0, 0};
uint16_t model_0_right_children_tree_20[17] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 0, 16, 0, 0};
uint8_t model_0_threshold_tree_20[17] = {131, 92, 234, 62, 0, 0, 20, 0, 0, 100, 20, 0, 0, 0, 122, 0, 0};
uint16_t model_0_features_tree_20[17] = {7, 3, 0, 1, 1, 1, 14, 0, 1, 5, 15, 0, 2, 1, 2, 0, 1};
uint16_t model_0_left_children_tree_21[29] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 14, 0, 0, 17, 18, 19, 0, 0, 22, 0, 0, 25, 26, 0, 0, 0};
uint16_t model_0_right_children_tree_21[29] = {16, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 15, 0, 0, 24, 21, 20, 0, 0, 23, 0, 0, 28, 27, 0, 0, 0};
uint8_t model_0_threshold_tree_21[29] = {36, 221, 27, 12, 0, 0, 74, 0, 0, 56, 25, 0, 0, 88, 0, 0, 160, 35, 215, 0, 0, 48, 0, 0, 66, 42, 0, 0, 0};
uint16_t model_0_features_tree_21[29] = {6, 0, 1, 1, 0, 2, 5, 1, 2, 4, 13, 0, 0, 12, 1, 2, 12, 13, 11, 2, 1, 13, 1, 1, 1, 8, 1, 2, 1};
uint16_t model_0_left_children_tree_22[15] = {1, 2, 3, 4, 0, 0, 0, 0, 9, 10, 11, 0, 0, 0, 0};
uint16_t model_0_right_children_tree_22[15] = {8, 7, 6, 5, 0, 0, 0, 0, 14, 13, 12, 0, 0, 0, 0};
uint8_t model_0_threshold_tree_22[15] = {224, 68, 77, 147, 0, 0, 0, 0, 54, 252, 1, 0, 0, 0, 0};
uint16_t model_0_features_tree_22[15] = {0, 8, 1, 7, 2, 1, 1, 1, 5, 11, 5, 1, 0, 1, 2};
uint16_t model_0_left_children_tree_23[23] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_23[23] = {14, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 13, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_23[23] = {30, 78, 88, 0, 30, 0, 0, 131, 104, 0, 0, 43, 0, 0, 70, 89, 223, 0, 0, 154, 0, 0, 0};
uint16_t model_0_features_tree_23[23] = {8, 7, 3, 1, 1, 0, 2, 7, 7, 0, 1, 15, 0, 1, 8, 12, 0, 1, 0, 0, 1, 2, 1};
uint16_t model_0_left_children_tree_24[25] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_24[25] = {12, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 22, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_24[25] = {217, 191, 81, 87, 0, 0, 70, 0, 0, 70, 0, 0, 53, 42, 1, 0, 0, 218, 0, 0, 31, 0, 134, 0, 0};
uint16_t model_0_features_tree_24[25] = {9, 12, 5, 7, 2, 1, 1, 2, 1, 8, 2, 1, 4, 6, 5, 1, 0, 0, 1, 2, 13, 2, 3, 1, 2};
uint16_t model_0_left_children_tree_25[19] = {1, 2, 3, 4, 0, 0, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_25[19] = {8, 7, 6, 5, 0, 0, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_25[19] = {28, 31, 47, 196, 0, 0, 0, 0, 91, 20, 222, 0, 0, 100, 0, 0, 60, 0, 0};
uint16_t model_0_features_tree_25[19] = {5, 14, 2, 11, 0, 0, 0, 1, 13, 15, 9, 1, 0, 5, 2, 1, 1, 2, 1};
uint16_t model_0_left_children_tree_26[21] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 13, 0, 0, 0, 17, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_26[21] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 16, 15, 14, 0, 0, 0, 18, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_26[21] = {219, 96, 85, 82, 0, 0, 77, 0, 0, 0, 44, 38, 25, 0, 0, 0, 130, 0, 102, 0, 0};
uint16_t model_0_features_tree_26[21] = {0, 13, 5, 3, 1, 2, 1, 2, 1, 1, 4, 12, 15, 0, 1, 0, 2, 2, 12, 0, 1};
uint16_t model_0_left_children_tree_27[13] = {1, 2, 0, 0, 5, 6, 7, 0, 0, 10, 0, 0, 0};
uint16_t model_0_right_children_tree_27[13] = {4, 3, 0, 0, 12, 9, 8, 0, 0, 11, 0, 0, 0};
uint8_t model_0_threshold_tree_27[13] = {38, 214, 0, 0, 72, 29, 15, 0, 0, 111, 0, 0, 0};
uint16_t model_0_features_tree_27[13] = {4, 0, 1, 0, 1, 1, 6, 0, 1, 12, 1, 2, 1};
uint16_t model_0_left_children_tree_28[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 12, 0, 0, 15, 16, 0, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_28[23] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 13, 0, 0, 20, 17, 0, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_28[23] = {221, 67, 203, 103, 0, 0, 108, 0, 0, 180, 0, 91, 0, 0, 44, 60, 0, 9, 0, 0, 48, 0, 0};
uint16_t model_0_features_tree_28[23] = {0, 1, 2, 3, 1, 2, 13, 2, 1, 11, 1, 5, 2, 1, 15, 7, 1, 5, 0, 0, 5, 1, 2};
uint16_t model_0_left_children_tree_29[25] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 13, 0, 0, 16, 0, 0, 19, 20, 0, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_29[25] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 18, 15, 14, 0, 0, 17, 0, 0, 22, 21, 0, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_29[25] = {223, 68, 47, 73, 0, 0, 61, 0, 0, 0, 53, 60, 24, 0, 0, 65, 0, 0, 215, 58, 0, 0, 92, 0, 0};
uint16_t model_0_features_tree_29[25] = {10, 8, 5, 13, 2, 1, 1, 2, 1, 1, 4, 15, 14, 0, 0, 1, 2, 1, 11, 3, 1, 2, 7, 1, 2};
uint16_t model_0_left_children_tree_30[27] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 12, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 23, 0, 25, 0, 0};
uint16_t model_0_right_children_tree_30[27] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 13, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 24, 0, 26, 0, 0};
uint8_t model_0_threshold_tree_30[27] = {217, 203, 216, 22, 0, 0, 109, 0, 0, 122, 0, 129, 0, 0, 42, 219, 96, 0, 0, 52, 0, 0, 31, 0, 45, 0, 0};
uint16_t model_0_features_tree_30[27] = {9, 2, 0, 14, 1, 1, 12, 2, 1, 12, 1, 6, 2, 1, 8, 0, 4, 1, 2, 4, 0, 1, 5, 0, 13, 2, 1};
uint16_t model_0_left_children_tree_31[17] = {1, 2, 0, 0, 5, 6, 7, 0, 0, 10, 0, 0, 13, 14, 0, 0, 0};
uint16_t model_0_right_children_tree_31[17] = {4, 3, 0, 0, 12, 9, 8, 0, 0, 11, 0, 0, 16, 15, 0, 0, 0};
uint8_t model_0_threshold_tree_31[17] = {29, 160, 0, 0, 67, 26, 42, 0, 0, 50, 0, 0, 68, 66, 0, 0, 0};
uint16_t model_0_features_tree_31[17] = {5, 11, 1, 0, 1, 15, 13, 0, 1, 3, 1, 2, 8, 13, 2, 1, 1};
uint16_t model_0_left_children_tree_32[17] = {1, 2, 0, 4, 5, 0, 0, 0, 9, 10, 0, 12, 0, 0, 15, 0, 0};
uint16_t model_0_right_children_tree_32[17] = {8, 3, 0, 7, 6, 0, 0, 0, 14, 11, 0, 13, 0, 0, 16, 0, 0};
uint8_t model_0_threshold_tree_32[17] = {219, 164, 0, 152, 69, 0, 0, 0, 35, 24, 0, 23, 0, 0, 88, 0, 0};
uint16_t model_0_features_tree_32[17] = {0, 9, 1, 7, 8, 2, 1, 1, 6, 14, 0, 4, 0, 1, 3, 1, 2};
uint16_t model_0_left_children_tree_33[19] = {1, 2, 3, 0, 5, 0, 0, 0, 9, 10, 11, 0, 0, 0, 15, 16, 0, 0, 0};
uint16_t model_0_right_children_tree_33[19] = {8, 7, 4, 0, 6, 0, 0, 0, 14, 13, 12, 0, 0, 0, 18, 17, 0, 0, 0};
uint8_t model_0_threshold_tree_33[19] = {38, 214, 169, 0, 16, 0, 0, 0, 99, 62, 42, 0, 0, 0, 124, 68, 0, 0, 0};
uint16_t model_0_features_tree_33[19] = {4, 0, 9, 1, 4, 1, 2, 0, 3, 1, 1, 1, 2, 1, 5, 2, 1, 2, 1};
uint16_t model_0_left_children_tree_34[15] = {1, 2, 3, 0, 5, 0, 0, 0, 9, 10, 11, 0, 0, 0, 0};
uint16_t model_0_right_children_tree_34[15] = {8, 7, 4, 0, 6, 0, 0, 0, 14, 13, 12, 0, 0, 0, 0};
uint8_t model_0_threshold_tree_34[15] = {96, 148, 52, 0, 57, 0, 0, 0, 71, 100, 64, 0, 0, 0, 0};
uint16_t model_0_features_tree_34[15] = {12, 2, 4, 0, 5, 1, 2, 1, 8, 13, 7, 1, 2, 1, 1};
uint16_t model_0_left_children_tree_35[25] = {1, 2, 3, 4, 0, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 0, 19, 20, 0, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_35[25] = {12, 7, 6, 5, 0, 0, 0, 11, 10, 0, 0, 0, 18, 17, 16, 0, 0, 0, 22, 21, 0, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_35[25] = {121, 144, 54, 61, 0, 0, 0, 229, 189, 0, 0, 0, 97, 248, 206, 0, 0, 0, 66, 106, 0, 0, 15, 0, 0};
uint16_t model_0_features_tree_35[25] = {2, 3, 5, 4, 0, 1, 2, 11, 9, 1, 2, 0, 3, 7, 2, 1, 1, 0, 7, 3, 1, 1, 8, 0, 2};
uint16_t model_0_left_children_tree_36[21] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 0, 15, 16, 0, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_36[21] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 0, 20, 17, 0, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_36[21] = {221, 87, 59, 50, 0, 0, 59, 0, 0, 100, 215, 0, 0, 0, 54, 39, 0, 26, 0, 0, 0};
uint16_t model_0_features_tree_36[21] = {0, 3, 8, 4, 1, 2, 4, 1, 1, 5, 11, 2, 1, 1, 5, 4, 0, 13, 2, 1, 2};
uint16_t model_0_left_children_tree_37[21] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_37[21] = {12, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_37[21] = {44, 73, 24, 0, 53, 0, 0, 89, 163, 0, 0, 0, 98, 97, 177, 0, 0, 21, 0, 0, 0};
uint16_t model_0_features_tree_37[21] = {4, 13, 14, 0, 2, 1, 0, 3, 11, 1, 1, 2, 5, 3, 10, 2, 1, 1, 0, 2, 1};
uint16_t model_0_left_children_tree_38[23] = {1, 2, 3, 4, 0, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 0, 17, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_38[23] = {14, 7, 6, 5, 0, 0, 0, 11, 10, 0, 0, 13, 0, 0, 16, 0, 20, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_38[23] = {34, 218, 149, 190, 0, 0, 0, 56, 38, 0, 0, 90, 0, 0, 164, 0, 99, 70, 0, 0, 84, 0, 0};
uint16_t model_0_features_tree_38[23] = {6, 9, 7, 9, 2, 1, 1, 4, 12, 0, 0, 4, 1, 2, 0, 1, 3, 8, 2, 1, 1, 2, 1};
uint16_t model_0_left_children_tree_39[21] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 0, 13, 14, 15, 0, 0, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_39[21] = {12, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 0, 18, 17, 16, 0, 0, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_39[21] = {223, 62, 111, 223, 0, 0, 180, 0, 0, 170, 0, 0, 53, 51, 1, 0, 0, 0, 237, 0, 0};
uint16_t model_0_features_tree_39[21] = {0, 1, 12, 11, 1, 0, 11, 2, 1, 3, 1, 2, 4, 6, 5, 1, 0, 2, 0, 1, 2};
uint16_t model_0_left_children_tree_40[19] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 13, 0, 0, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_40[19] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 16, 15, 14, 0, 0, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_40[19] = {219, 115, 55, 114, 0, 0, 100, 0, 0, 0, 102, 190, 42, 0, 0, 0, 225, 0, 0};
uint16_t model_0_features_tree_40[19] = {0, 6, 6, 3, 1, 2, 13, 2, 1, 1, 12, 11, 4, 0, 1, 0, 0, 1, 2};
uint16_t model_0_left_children_tree_41[25] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 0, 19, 20, 0, 0, 23, 0, 0};
uint16_t model_0_right_children_tree_41[25] = {12, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 0, 18, 17, 16, 0, 0, 0, 22, 21, 0, 0, 24, 0, 0};
uint8_t model_0_threshold_tree_41[25] = {42, 217, 79, 0, 117, 0, 0, 40, 37, 0, 0, 0, 101, 64, 176, 0, 0, 0, 26, 54, 0, 0, 224, 0, 0};
uint16_t model_0_features_tree_41[25] = {4, 0, 3, 1, 0, 1, 2, 12, 12, 0, 1, 0, 3, 1, 11, 2, 1, 1, 6, 13, 0, 1, 4, 2, 1};
uint16_t model_0_left_children_tree_42[19] = {1, 2, 3, 0, 0, 0, 7, 8, 9, 0, 0, 12, 0, 0, 15, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_42[19] = {6, 5, 4, 0, 0, 0, 14, 11, 10, 0, 0, 13, 0, 0, 16, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_42[19] = {28, 168, 56, 0, 0, 0, 62, 20, 251, 0, 0, 52, 0, 0, 203, 0, 213, 0, 0};
uint16_t model_0_features_tree_42[19] = {5, 2, 4, 0, 1, 1, 1, 15, 10, 1, 0, 3, 1, 2, 0, 1, 10, 1, 1};
uint16_t model_0_left_children_tree_43[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 13, 0, 0, 16, 0, 0, 19, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_43[23] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 18, 15, 14, 0, 0, 17, 0, 0, 22, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_43[23] = {229, 70, 172, 19, 0, 0, 194, 0, 0, 0, 143, 233, 88, 0, 0, 8, 0, 0, 44, 28, 0, 0, 0};
uint16_t model_0_features_tree_43[23] = {9, 8, 12, 1, 0, 1, 9, 2, 1, 1, 3, 0, 3, 1, 0, 14, 0, 0, 1, 1, 0, 1, 2};
uint16_t model_0_left_children_tree_44[15] = {1, 2, 3, 0, 5, 0, 0, 0, 9, 10, 11, 0, 0, 0, 0};
uint16_t model_0_right_children_tree_44[15] = {8, 7, 4, 0, 6, 0, 0, 0, 14, 13, 12, 0, 0, 0, 0};
uint8_t model_0_threshold_tree_44[15] = {28, 168, 242, 0, 24, 0, 0, 0, 234, 68, 94, 0, 0, 0, 0};
uint16_t model_0_features_tree_44[15] = {5, 2, 10, 0, 14, 0, 1, 1, 0, 8, 12, 1, 2, 1, 0};
uint16_t model_0_left_children_tree_45[21] = {1, 2, 3, 0, 0, 6, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 17, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_45[21] = {8, 5, 4, 0, 0, 7, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 20, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_45[21] = {36, 31, 104, 0, 0, 31, 0, 0, 65, 57, 187, 0, 0, 64, 0, 0, 69, 132, 0, 0, 0};
uint16_t model_0_features_tree_45[21] = {5, 14, 12, 0, 2, 1, 2, 1, 8, 12, 11, 1, 0, 3, 1, 2, 5, 15, 1, 2, 1};
uint16_t model_0_left_children_tree_46[17] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 0, 14, 0, 0, 0};
uint16_t model_0_right_children_tree_46[17] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 16, 13, 0, 15, 0, 0, 0};
uint8_t model_0_threshold_tree_46[17] = {223, 70, 30, 148, 0, 0, 68, 0, 0, 0, 60, 57, 0, 12, 0, 0, 0};
uint16_t model_0_features_tree_46[17] = {0, 8, 6, 7, 2, 1, 7, 1, 2, 1, 15, 7, 1, 13, 0, 0, 2};
uint16_t model_0_left_children_tree_47[21] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_47[21] = {12, 9, 6, 5, 0, 0, 8, 0, 0, 11, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_47[21] = {23, 75, 53, 25, 0, 0, 109, 0, 0, 123, 0, 0, 70, 20, 36, 0, 0, 80, 0, 0, 0};
uint16_t model_0_features_tree_47[21] = {6, 13, 4, 13, 0, 0, 7, 2, 1, 11, 2, 1, 8, 15, 2, 0, 1, 1, 2, 1, 1};
uint16_t model_0_left_children_tree_48[23] = {1, 2, 3, 0, 0, 6, 7, 0, 0, 0, 11, 12, 13, 0, 0, 0, 17, 18, 0, 0, 21, 0, 0};
uint16_t model_0_right_children_tree_48[23] = {10, 5, 4, 0, 0, 9, 8, 0, 0, 0, 16, 15, 14, 0, 0, 0, 20, 19, 0, 0, 22, 0, 0};
uint8_t model_0_threshold_tree_48[23] = {29, 219, 152, 0, 0, 252, 24, 0, 0, 0, 82, 60, 52, 0, 0, 0, 119, 68, 0, 0, 175, 0, 0};
uint16_t model_0_features_tree_48[23] = {14, 0, 3, 1, 2, 11, 14, 0, 0, 1, 3, 1, 1, 1, 2, 1, 4, 8, 2, 1, 3, 1, 2};
uint16_t model_0_left_children_tree_49[17] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 13, 0, 0, 0, 0};
uint16_t model_0_right_children_tree_49[17] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 16, 15, 14, 0, 0, 0, 0};
uint8_t model_0_threshold_tree_49[17] = {223, 70, 202, 212, 0, 0, 34, 0, 0, 0, 52, 60, 24, 0, 0, 0, 0};
uint16_t model_0_features_tree_49[17] = {0, 8, 2, 9, 1, 2, 3, 1, 2, 1, 4, 15, 14, 0, 0, 2, 1};
uint16_t model_0_left_children_tree_50[19] = {1, 2, 0, 4, 5, 0, 0, 8, 0, 0, 11, 12, 13, 0, 0, 16, 0, 0, 0};
uint16_t model_0_right_children_tree_50[19] = {10, 3, 0, 7, 6, 0, 0, 9, 0, 0, 18, 15, 14, 0, 0, 17, 0, 0, 0};
uint8_t model_0_threshold_tree_50[19] = {219, 167, 0, 202, 50, 0, 0, 156, 0, 0, 115, 24, 52, 0, 0, 37, 0, 0, 0};
uint16_t model_0_features_tree_50[19] = {0, 0, 1, 2, 13, 2, 1, 12, 1, 2, 12, 14, 4, 0, 1, 3, 0, 1, 2};
uint16_t model_0_left_children_tree_51[19] = {1, 2, 3, 0, 0, 0, 7, 8, 9, 0, 0, 12, 0, 0, 15, 16, 0, 0, 0};
uint16_t model_0_right_children_tree_51[19] = {6, 5, 4, 0, 0, 0, 14, 11, 10, 0, 0, 13, 0, 0, 18, 17, 0, 0, 0};
uint8_t model_0_threshold_tree_51[19] = {31, 168, 164, 0, 0, 0, 97, 181, 78, 0, 0, 14, 0, 0, 76, 28, 0, 0, 0};
uint16_t model_0_features_tree_51[19] = {4, 11, 9, 1, 2, 0, 3, 10, 7, 1, 2, 8, 0, 1, 1, 15, 0, 2, 1};
uint16_t model_0_left_children_tree_52[21] = {1, 2, 0, 4, 0, 6, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 17, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_52[21] = {8, 3, 0, 5, 0, 7, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 18, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_52[21] = {24, 216, 0, 2, 0, 53, 0, 0, 85, 37, 49, 0, 0, 152, 0, 0, 97, 0, 67, 0, 0};
uint16_t model_0_features_tree_52[21] = {6, 9, 1, 5, 1, 4, 0, 2, 5, 6, 13, 0, 1, 0, 1, 2, 2, 2, 1, 2, 1};
uint16_t model_0_left_children_tree_53[19] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 13, 0, 0, 16, 0, 0, 0};
uint16_t model_0_right_children_tree_53[19] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 18, 15, 14, 0, 0, 17, 0, 0, 0};
uint8_t model_0_threshold_tree_53[19] = {224, 72, 82, 115, 0, 0, 44, 0, 0, 0, 97, 56, 2, 0, 0, 183, 0, 0, 0};
uint16_t model_0_features_tree_53[19] = {9, 1, 3, 7, 2, 1, 7, 1, 2, 1, 12, 5, 14, 0, 0, 11, 1, 2, 2};
uint16_t model_0_left_children_tree_54[21] = {1, 2, 3, 0, 0, 6, 7, 0, 0, 10, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_54[21] = {12, 5, 4, 0, 0, 9, 8, 0, 0, 11, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_54[21] = {23, 47, 216, 0, 0, 61, 88, 0, 0, 160, 0, 0, 71, 168, 202, 0, 0, 10, 0, 0, 0};
uint16_t model_0_features_tree_54[21] = {14, 4, 9, 1, 0, 13, 3, 1, 2, 3, 1, 2, 1, 11, 2, 2, 2, 6, 0, 1, 1};
uint16_t model_0_left_children_tree_55[25] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 22, 0, 0, 0};
uint16_t model_0_right_children_tree_55[25] = {12, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 24, 23, 0, 0, 0};
uint8_t model_0_threshold_tree_55[25] = {29, 40, 217, 0, 125, 0, 0, 236, 14, 0, 0, 0, 97, 47, 242, 0, 0, 61, 0, 0, 100, 233, 0, 0, 0};
uint16_t model_0_features_tree_55[25] = {8, 4, 0, 1, 7, 0, 0, 0, 1, 0, 1, 0, 3, 13, 9, 2, 0, 1, 2, 1, 5, 0, 2, 0, 1};
uint16_t model_0_left_children_tree_56[21] = {1, 2, 3, 0, 0, 6, 7, 0, 0, 10, 0, 0, 13, 14, 0, 0, 17, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_56[21] = {12, 5, 4, 0, 0, 9, 8, 0, 0, 11, 0, 0, 16, 15, 0, 0, 18, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_56[21] = {87, 219, 228, 0, 0, 2, 32, 0, 0, 1, 0, 0, 65, 37, 0, 0, 154, 0, 71, 0, 0};
uint16_t model_0_features_tree_56[21] = {12, 0, 9, 1, 2, 14, 12, 0, 1, 5, 1, 0, 7, 13, 2, 1, 10, 1, 8, 2, 1};
uint16_t model_0_left_children_tree_57[15] = {1, 2, 3, 0, 5, 0, 0, 8, 0, 0, 11, 0, 13, 0, 0};
uint16_t model_0_right_children_tree_57[15] = {10, 7, 4, 0, 6, 0, 0, 9, 0, 0, 12, 0, 14, 0, 0};
uint8_t model_0_threshold_tree_57[15] = {221, 85, 165, 0, 70, 0, 0, 67, 0, 0, 49, 0, 34, 0, 0};
uint16_t model_0_features_tree_57[15] = {0, 5, 0, 1, 8, 2, 1, 1, 2, 1, 4, 0, 5, 1, 2};
uint16_t model_0_left_children_tree_58[23] = {1, 2, 3, 4, 0, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 0, 19, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_58[23] = {12, 7, 6, 5, 0, 0, 0, 11, 10, 0, 0, 0, 18, 17, 16, 0, 0, 0, 22, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_58[23] = {34, 216, 94, 121, 0, 0, 0, 129, 20, 0, 0, 0, 92, 61, 39, 0, 0, 0, 75, 41, 0, 0, 0};
uint16_t model_0_features_tree_58[23] = {6, 9, 3, 7, 2, 1, 2, 7, 14, 0, 1, 0, 3, 1, 1, 1, 2, 1, 1, 8, 2, 2, 1};
uint16_t model_0_left_children_tree_59[23] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 10, 11, 0, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_59[23] = {14, 9, 6, 5, 0, 0, 8, 0, 0, 13, 12, 0, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_59[23] = {87, 25, 216, 58, 0, 0, 2, 0, 0, 63, 131, 0, 0, 0, 70, 66, 204, 0, 0, 82, 0, 0, 0};
uint16_t model_0_features_tree_59[23] = {12, 14, 0, 7, 2, 1, 14, 0, 0, 13, 7, 1, 0, 1, 8, 3, 2, 1, 2, 1, 2, 1, 1};
uint16_t model_0_left_children_tree_60[25] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 22, 0, 0, 0};
uint16_t model_0_right_children_tree_60[25] = {12, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 24, 23, 0, 0, 0};
uint8_t model_0_threshold_tree_60[25] = {38, 50, 193, 0, 24, 0, 0, 29, 206, 0, 0, 0, 65, 87, 178, 0, 0, 33, 0, 0, 107, 77, 0, 0, 0};
uint16_t model_0_features_tree_60[25] = {4, 15, 10, 1, 14, 0, 0, 6, 0, 2, 1, 1, 1, 3, 11, 2, 1, 6, 0, 2, 2, 1, 2, 1, 1};
uint16_t model_0_left_children_tree_61[21] = {1, 2, 0, 4, 5, 0, 0, 8, 0, 0, 11, 12, 0, 14, 0, 0, 17, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_61[21] = {10, 3, 0, 7, 6, 0, 0, 9, 0, 0, 16, 13, 0, 15, 0, 0, 18, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_61[21] = {229, 165, 0, 87, 28, 0, 0, 196, 0, 0, 75, 9, 0, 123, 0, 0, 165, 0, 34, 0, 0};
uint16_t model_0_features_tree_61[21] = {9, 0, 1, 3, 5, 0, 1, 4, 2, 1, 7, 15, 1, 3, 1, 2, 11, 2, 8, 0, 0};
uint16_t model_0_left_children_tree_62[25] = {1, 2, 3, 4, 0, 0, 0, 8, 0, 10, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 22, 0, 0, 0};
uint16_t model_0_right_children_tree_62[25] = {12, 7, 6, 5, 0, 0, 0, 9, 0, 11, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 24, 23, 0, 0, 0};
uint8_t model_0_threshold_tree_62[25] = {34, 218, 32, 228, 0, 0, 0, 1, 0, 53, 0, 0, 84, 82, 58, 0, 0, 31, 0, 0, 203, 90, 0, 0, 0};
uint16_t model_0_features_tree_62[25] = {6, 9, 1, 11, 2, 1, 1, 5, 1, 4, 0, 2, 5, 3, 15, 1, 2, 7, 1, 2, 3, 5, 1, 1, 2};
uint16_t model_0_left_children_tree_63[23] = {1, 2, 3, 0, 5, 0, 0, 8, 9, 0, 0, 12, 0, 0, 15, 16, 17, 0, 0, 20, 0, 0, 0};
uint16_t model_0_right_children_tree_63[23] = {14, 7, 4, 0, 6, 0, 0, 11, 10, 0, 0, 13, 0, 0, 22, 19, 18, 0, 0, 21, 0, 0, 0};
uint8_t model_0_threshold_tree_63[23] = {96, 34, 193, 0, 117, 0, 0, 251, 210, 0, 0, 79, 0, 0, 70, 47, 40, 0, 0, 154, 0, 0, 0};
uint16_t model_0_features_tree_63[23] = {12, 5, 10, 1, 7, 0, 0, 10, 9, 1, 1, 12, 0, 2, 8, 5, 5, 2, 1, 0, 1, 2, 1};
uint16_t model_0_left_children_tree_64[25] = {1, 2, 3, 4, 0, 0, 0, 8, 9, 0, 0, 0, 13, 14, 15, 0, 0, 18, 0, 0, 21, 22, 0, 0, 0};
uint16_t model_0_right_children_tree_64[25] = {12, 7, 6, 5, 0, 0, 0, 11, 10, 0, 0, 0, 20, 17, 16, 0, 0, 19, 0, 0, 24, 23, 0, 0, 0};
uint8_t model_0_threshold_tree_64[25] = {35, 152, 62, 52, 0, 0, 0, 92, 21, 0, 0, 0, 85, 203, 48, 0, 0, 161, 0, 0, 66, 166, 0, 0, 0};
uint16_t model_0_features_tree_64[25] = {6, 2, 15, 4, 0, 1, 1, 15, 4, 1, 1, 2, 5, 2, 6, 1, 2, 12, 1, 2, 8, 9, 1, 2, 1};
uint16_t model_0_left_children_tree_65[17] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 0, 0, 15, 0, 0};
uint16_t model_0_right_children_tree_65[17] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 14, 13, 0, 0, 16, 0, 0};
uint8_t model_0_threshold_tree_65[17] = {221, 70, 87, 203, 0, 0, 103, 0, 0, 0, 52, 1, 0, 0, 27, 0, 0};
uint16_t model_0_features_tree_65[17] = {0, 8, 3, 2, 1, 2, 0, 1, 2, 1, 4, 5, 1, 0, 8, 1, 2};
uint16_t model_0_left_children_tree_66[19] = {1, 2, 3, 4, 0, 0, 7, 0, 0, 0, 11, 12, 0, 0, 15, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_66[19] = {10, 9, 6, 5, 0, 0, 8, 0, 0, 0, 14, 13, 0, 0, 16, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_66[19] = {219, 70, 32, 92, 0, 0, 65, 0, 0, 0, 52, 109, 0, 0, 22, 0, 82, 0, 0};
uint16_t model_0_features_tree_66[19] = {0, 8, 8, 12, 1, 2, 1, 2, 1, 1, 4, 12, 0, 1, 6, 1, 4, 1, 2};
uint16_t model_0_left_children_tree_67[19] = {1, 2, 0, 4, 0, 6, 0, 0, 9, 10, 11, 0, 0, 14, 0, 0, 17, 0, 0};
uint16_t model_0_right_children_tree_67[19] = {8, 3, 0, 5, 0, 7, 0, 0, 16, 13, 12, 0, 0, 15, 0, 0, 18, 0, 0};
uint8_t model_0_threshold_tree_67[19] = {28, 160, 0, 24, 0, 60, 0, 0, 61, 36, 49, 0, 0, 25, 0, 0, 17, 0, 0};
uint16_t model_0_features_tree_67[19] = {5, 11, 1, 14, 0, 2, 1, 0, 1, 2, 4, 0, 1, 8, 1, 2, 13, 2, 1};
uint16_t model_0_left_children_tree_68[21] = {1, 2, 3, 4, 0, 0, 0, 8, 0, 10, 0, 0, 13, 14, 15, 0, 0, 0, 19, 0, 0};
uint16_t model_0_right_children_tree_68[21] = {12, 7, 6, 5, 0, 0, 0, 9, 0, 11, 0, 0, 18, 17, 16, 0, 0, 0, 20, 0, 0};
uint8_t model_0_threshold_tree_68[21] = {221, 202, 65, 206, 0, 0, 0, 166, 0, 98, 0, 0, 103, 53, 1, 0, 0, 0, 38, 0, 0};
uint16_t model_0_features_tree_68[21] = {0, 2, 1, 9, 1, 2, 1, 0, 1, 13, 2, 1, 12, 4, 5, 1, 0, 1, 15, 2, 1};
uint16_t model_0_left_children_tree_69[21] = {1, 2, 3, 0, 5, 0, 0, 8, 0, 0, 11, 12, 13, 0, 0, 0, 17, 18, 0, 0, 0};
uint16_t model_0_right_children_tree_69[21] = {10, 7, 4, 0, 6, 0, 0, 9, 0, 0, 16, 15, 14, 0, 0, 0, 20, 19, 0, 0, 0};
uint8_t model_0_threshold_tree_69[21] = {25, 147, 172, 0, 58, 0, 0, 172, 0, 0, 64, 61, 15, 0, 0, 0, 60, 96, 0, 0, 0};
uint16_t model_0_features_tree_69[21] = {14, 3, 11, 1, 5, 0, 1, 11, 1, 2, 8, 1, 6, 0, 2, 1, 1, 3, 1, 2, 1};
tree_t forest_ensemble_models_0[70] = {
	{
		.left_children = model_0_left_children_tree_0,
		.right_children = model_0_right_children_tree_0,
		.threshold = model_0_threshold_tree_0,
		.features = model_0_features_tree_0,
	},
	{
		.left_children = model_0_left_children_tree_1,
		.right_children = model_0_right_children_tree_1,
		.threshold = model_0_threshold_tree_1,
		.features = model_0_features_tree_1,
	},
	{
		.left_children = model_0_left_children_tree_2,
		.right_children = model_0_right_children_tree_2,
		.threshold = model_0_threshold_tree_2,
		.features = model_0_features_tree_2,
	},
	{
		.left_children = model_0_left_children_tree_3,
		.right_children = model_0_right_children_tree_3,
		.threshold = model_0_threshold_tree_3,
		.features = model_0_features_tree_3,
	},
	{
		.left_children = model_0_left_children_tree_4,
		.right_children = model_0_right_children_tree_4,
		.threshold = model_0_threshold_tree_4,
		.features = model_0_features_tree_4,
	},
	{
		.left_children = model_0_left_children_tree_5,
		.right_children = model_0_right_children_tree_5,
		.threshold = model_0_threshold_tree_5,
		.features = model_0_features_tree_5,
	},
	{
		.left_children = model_0_left_children_tree_6,
		.right_children = model_0_right_children_tree_6,
		.threshold = model_0_threshold_tree_6,
		.features = model_0_features_tree_6,
	},
	{
		.left_children = model_0_left_children_tree_7,
		.right_children = model_0_right_children_tree_7,
		.threshold = model_0_threshold_tree_7,
		.features = model_0_features_tree_7,
	},
	{
		.left_children = model_0_left_children_tree_8,
		.right_children = model_0_right_children_tree_8,
		.threshold = model_0_threshold_tree_8,
		.features = model_0_features_tree_8,
	},
	{
		.left_children = model_0_left_children_tree_9,
		.right_children = model_0_right_children_tree_9,
		.threshold = model_0_threshold_tree_9,
		.features = model_0_features_tree_9,
	},
	{
		.left_children = model_0_left_children_tree_10,
		.right_children = model_0_right_children_tree_10,
		.threshold = model_0_threshold_tree_10,
		.features = model_0_features_tree_10,
	},
	{
		.left_children = model_0_left_children_tree_11,
		.right_children = model_0_right_children_tree_11,
		.threshold = model_0_threshold_tree_11,
		.features = model_0_features_tree_11,
	},
	{
		.left_children = model_0_left_children_tree_12,
		.right_children = model_0_right_children_tree_12,
		.threshold = model_0_threshold_tree_12,
		.features = model_0_features_tree_12,
	},
	{
		.left_children = model_0_left_children_tree_13,
		.right_children = model_0_right_children_tree_13,
		.threshold = model_0_threshold_tree_13,
		.features = model_0_features_tree_13,
	},
	{
		.left_children = model_0_left_children_tree_14,
		.right_children = model_0_right_children_tree_14,
		.threshold = model_0_threshold_tree_14,
		.features = model_0_features_tree_14,
	},
	{
		.left_children = model_0_left_children_tree_15,
		.right_children = model_0_right_children_tree_15,
		.threshold = model_0_threshold_tree_15,
		.features = model_0_features_tree_15,
	},
	{
		.left_children = model_0_left_children_tree_16,
		.right_children = model_0_right_children_tree_16,
		.threshold = model_0_threshold_tree_16,
		.features = model_0_features_tree_16,
	},
	{
		.left_children = model_0_left_children_tree_17,
		.right_children = model_0_right_children_tree_17,
		.threshold = model_0_threshold_tree_17,
		.features = model_0_features_tree_17,
	},
	{
		.left_children = model_0_left_children_tree_18,
		.right_children = model_0_right_children_tree_18,
		.threshold = model_0_threshold_tree_18,
		.features = model_0_features_tree_18,
	},
	{
		.left_children = model_0_left_children_tree_19,
		.right_children = model_0_right_children_tree_19,
		.threshold = model_0_threshold_tree_19,
		.features = model_0_features_tree_19,
	},
	{
		.left_children = model_0_left_children_tree_20,
		.right_children = model_0_right_children_tree_20,
		.threshold = model_0_threshold_tree_20,
		.features = model_0_features_tree_20,
	},
	{
		.left_children = model_0_left_children_tree_21,
		.right_children = model_0_right_children_tree_21,
		.threshold = model_0_threshold_tree_21,
		.features = model_0_features_tree_21,
	},
	{
		.left_children = model_0_left_children_tree_22,
		.right_children = model_0_right_children_tree_22,
		.threshold = model_0_threshold_tree_22,
		.features = model_0_features_tree_22,
	},
	{
		.left_children = model_0_left_children_tree_23,
		.right_children = model_0_right_children_tree_23,
		.threshold = model_0_threshold_tree_23,
		.features = model_0_features_tree_23,
	},
	{
		.left_children = model_0_left_children_tree_24,
		.right_children = model_0_right_children_tree_24,
		.threshold = model_0_threshold_tree_24,
		.features = model_0_features_tree_24,
	},
	{
		.left_children = model_0_left_children_tree_25,
		.right_children = model_0_right_children_tree_25,
		.threshold = model_0_threshold_tree_25,
		.features = model_0_features_tree_25,
	},
	{
		.left_children = model_0_left_children_tree_26,
		.right_children = model_0_right_children_tree_26,
		.threshold = model_0_threshold_tree_26,
		.features = model_0_features_tree_26,
	},
	{
		.left_children = model_0_left_children_tree_27,
		.right_children = model_0_right_children_tree_27,
		.threshold = model_0_threshold_tree_27,
		.features = model_0_features_tree_27,
	},
	{
		.left_children = model_0_left_children_tree_28,
		.right_children = model_0_right_children_tree_28,
		.threshold = model_0_threshold_tree_28,
		.features = model_0_features_tree_28,
	},
	{
		.left_children = model_0_left_children_tree_29,
		.right_children = model_0_right_children_tree_29,
		.threshold = model_0_threshold_tree_29,
		.features = model_0_features_tree_29,
	},
	{
		.left_children = model_0_left_children_tree_30,
		.right_children = model_0_right_children_tree_30,
		.threshold = model_0_threshold_tree_30,
		.features = model_0_features_tree_30,
	},
	{
		.left_children = model_0_left_children_tree_31,
		.right_children = model_0_right_children_tree_31,
		.threshold = model_0_threshold_tree_31,
		.features = model_0_features_tree_31,
	},
	{
		.left_children = model_0_left_children_tree_32,
		.right_children = model_0_right_children_tree_32,
		.threshold = model_0_threshold_tree_32,
		.features = model_0_features_tree_32,
	},
	{
		.left_children = model_0_left_children_tree_33,
		.right_children = model_0_right_children_tree_33,
		.threshold = model_0_threshold_tree_33,
		.features = model_0_features_tree_33,
	},
	{
		.left_children = model_0_left_children_tree_34,
		.right_children = model_0_right_children_tree_34,
		.threshold = model_0_threshold_tree_34,
		.features = model_0_features_tree_34,
	},
	{
		.left_children = model_0_left_children_tree_35,
		.right_children = model_0_right_children_tree_35,
		.threshold = model_0_threshold_tree_35,
		.features = model_0_features_tree_35,
	},
	{
		.left_children = model_0_left_children_tree_36,
		.right_children = model_0_right_children_tree_36,
		.threshold = model_0_threshold_tree_36,
		.features = model_0_features_tree_36,
	},
	{
		.left_children = model_0_left_children_tree_37,
		.right_children = model_0_right_children_tree_37,
		.threshold = model_0_threshold_tree_37,
		.features = model_0_features_tree_37,
	},
	{
		.left_children = model_0_left_children_tree_38,
		.right_children = model_0_right_children_tree_38,
		.threshold = model_0_threshold_tree_38,
		.features = model_0_features_tree_38,
	},
	{
		.left_children = model_0_left_children_tree_39,
		.right_children = model_0_right_children_tree_39,
		.threshold = model_0_threshold_tree_39,
		.features = model_0_features_tree_39,
	},
	{
		.left_children = model_0_left_children_tree_40,
		.right_children = model_0_right_children_tree_40,
		.threshold = model_0_threshold_tree_40,
		.features = model_0_features_tree_40,
	},
	{
		.left_children = model_0_left_children_tree_41,
		.right_children = model_0_right_children_tree_41,
		.threshold = model_0_threshold_tree_41,
		.features = model_0_features_tree_41,
	},
	{
		.left_children = model_0_left_children_tree_42,
		.right_children = model_0_right_children_tree_42,
		.threshold = model_0_threshold_tree_42,
		.features = model_0_features_tree_42,
	},
	{
		.left_children = model_0_left_children_tree_43,
		.right_children = model_0_right_children_tree_43,
		.threshold = model_0_threshold_tree_43,
		.features = model_0_features_tree_43,
	},
	{
		.left_children = model_0_left_children_tree_44,
		.right_children = model_0_right_children_tree_44,
		.threshold = model_0_threshold_tree_44,
		.features = model_0_features_tree_44,
	},
	{
		.left_children = model_0_left_children_tree_45,
		.right_children = model_0_right_children_tree_45,
		.threshold = model_0_threshold_tree_45,
		.features = model_0_features_tree_45,
	},
	{
		.left_children = model_0_left_children_tree_46,
		.right_children = model_0_right_children_tree_46,
		.threshold = model_0_threshold_tree_46,
		.features = model_0_features_tree_46,
	},
	{
		.left_children = model_0_left_children_tree_47,
		.right_children = model_0_right_children_tree_47,
		.threshold = model_0_threshold_tree_47,
		.features = model_0_features_tree_47,
	},
	{
		.left_children = model_0_left_children_tree_48,
		.right_children = model_0_right_children_tree_48,
		.threshold = model_0_threshold_tree_48,
		.features = model_0_features_tree_48,
	},
	{
		.left_children = model_0_left_children_tree_49,
		.right_children = model_0_right_children_tree_49,
		.threshold = model_0_threshold_tree_49,
		.features = model_0_features_tree_49,
	},
	{
		.left_children = model_0_left_children_tree_50,
		.right_children = model_0_right_children_tree_50,
		.threshold = model_0_threshold_tree_50,
		.features = model_0_features_tree_50,
	},
	{
		.left_children = model_0_left_children_tree_51,
		.right_children = model_0_right_children_tree_51,
		.threshold = model_0_threshold_tree_51,
		.features = model_0_features_tree_51,
	},
	{
		.left_children = model_0_left_children_tree_52,
		.right_children = model_0_right_children_tree_52,
		.threshold = model_0_threshold_tree_52,
		.features = model_0_features_tree_52,
	},
	{
		.left_children = model_0_left_children_tree_53,
		.right_children = model_0_right_children_tree_53,
		.threshold = model_0_threshold_tree_53,
		.features = model_0_features_tree_53,
	},
	{
		.left_children = model_0_left_children_tree_54,
		.right_children = model_0_right_children_tree_54,
		.threshold = model_0_threshold_tree_54,
		.features = model_0_features_tree_54,
	},
	{
		.left_children = model_0_left_children_tree_55,
		.right_children = model_0_right_children_tree_55,
		.threshold = model_0_threshold_tree_55,
		.features = model_0_features_tree_55,
	},
	{
		.left_children = model_0_left_children_tree_56,
		.right_children = model_0_right_children_tree_56,
		.threshold = model_0_threshold_tree_56,
		.features = model_0_features_tree_56,
	},
	{
		.left_children = model_0_left_children_tree_57,
		.right_children = model_0_right_children_tree_57,
		.threshold = model_0_threshold_tree_57,
		.features = model_0_features_tree_57,
	},
	{
		.left_children = model_0_left_children_tree_58,
		.right_children = model_0_right_children_tree_58,
		.threshold = model_0_threshold_tree_58,
		.features = model_0_features_tree_58,
	},
	{
		.left_children = model_0_left_children_tree_59,
		.right_children = model_0_right_children_tree_59,
		.threshold = model_0_threshold_tree_59,
		.features = model_0_features_tree_59,
	},
	{
		.left_children = model_0_left_children_tree_60,
		.right_children = model_0_right_children_tree_60,
		.threshold = model_0_threshold_tree_60,
		.features = model_0_features_tree_60,
	},
	{
		.left_children = model_0_left_children_tree_61,
		.right_children = model_0_right_children_tree_61,
		.threshold = model_0_threshold_tree_61,
		.features = model_0_features_tree_61,
	},
	{
		.left_children = model_0_left_children_tree_62,
		.right_children = model_0_right_children_tree_62,
		.threshold = model_0_threshold_tree_62,
		.features = model_0_features_tree_62,
	},
	{
		.left_children = model_0_left_children_tree_63,
		.right_children = model_0_right_children_tree_63,
		.threshold = model_0_threshold_tree_63,
		.features = model_0_features_tree_63,
	},
	{
		.left_children = model_0_left_children_tree_64,
		.right_children = model_0_right_children_tree_64,
		.threshold = model_0_threshold_tree_64,
		.features = model_0_features_tree_64,
	},
	{
		.left_children = model_0_left_children_tree_65,
		.right_children = model_0_right_children_tree_65,
		.threshold = model_0_threshold_tree_65,
		.features = model_0_features_tree_65,
	},
	{
		.left_children = model_0_left_children_tree_66,
		.right_children = model_0_right_children_tree_66,
		.threshold = model_0_threshold_tree_66,
		.features = model_0_features_tree_66,
	},
	{
		.left_children = model_0_left_children_tree_67,
		.right_children = model_0_right_children_tree_67,
		.threshold = model_0_threshold_tree_67,
		.features = model_0_features_tree_67,
	},
	{
		.left_children = model_0_left_children_tree_68,
		.right_children = model_0_right_children_tree_68,
		.threshold = model_0_threshold_tree_68,
		.features = model_0_features_tree_68,
	},
	{
		.left_children = model_0_left_children_tree_69,
		.right_children = model_0_right_children_tree_69,
		.threshold = model_0_threshold_tree_69,
		.features = model_0_features_tree_69,
	},
};
tree_ensemble_classifier_rows_t tree_ensemble_classifier_rows[1] = {

	{
		.number_of_classes=3,
		.number_of_trees=70,
		.tree_ensemble=forest_ensemble_models_0,
	},
};

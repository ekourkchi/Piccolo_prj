/*
Copyright 2017-2024 SensiML Corporation

This file is part of SensiML™ Piccolo AI™.

SensiML Piccolo AI is free software: you can redistribute it and/or
modify it under the terms of the GNU Affero General Public License
as published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

SensiML Piccolo AI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public
License along with SensiML Piccolo AI. If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef __MODEL_JSON_H__
#define __MODEL_JSON_H__

const char recognition_model_string_json[] = {"{\"NumModels\":1,\"ModelIndexes\":{\"0\":\"XG_BOOST_WB_X_O_FOLD_0\"},\"ModelDescriptions\":[{\"Name\":\"XG_BOOST_WB_X_O_FOLD_0\",\"ClassMaps\":{\"1\":\"O\",\"2\":\"X\",\"0\":\"Unknown\"},\"ModelType\":\"BoostedTreeEnsemble\",\"FeatureFunctions\":[\"25thPercentile\",\"25thPercentile\",\"25thPercentile\",\"75thPercentile\",\"75thPercentile\",\"75thPercentile\",\"AbsoluteMean\",\"AbsoluteSum\",\"AbsoluteSum\",\"InterquartileRange\",\"InterquartileRange\",\"InterquartileRange\",\"Kurtosis\",\"Kurtosis\",\"Kurtosis\",\"LinearRegressionStats\",\"LinearRegressionStats\",\"LinearRegressionStats\",\"LinearRegressionStats\",\"LinearRegressionStats\",\"LinearRegressionStats\",\"LinearRegressionStats\",\"Maximum\",\"Maximum\",\"Maximum\",\"Mean\",\"Median\",\"Minimum\",\"Minimum\",\"NegativeZeroCrossings\",\"NegativeZeroCrossings\",\"NegativeZeroCrossings\",\"PositiveZeroCrossings\",\"PositiveZeroCrossings\",\"PositiveZeroCrossings\",\"Skewness\",\"Skewness\",\"StandardDeviation\",\"Sum\",\"Variance\"]}]}"};

int32_t recognition_model_string_json_len = sizeof(recognition_model_string_json);

#endif /* __MODEL_JSON_H__ */
